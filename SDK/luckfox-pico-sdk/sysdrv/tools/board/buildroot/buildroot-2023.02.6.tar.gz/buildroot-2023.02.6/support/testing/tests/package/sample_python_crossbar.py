import os
import crossbar

crossbar.run(["version"])
