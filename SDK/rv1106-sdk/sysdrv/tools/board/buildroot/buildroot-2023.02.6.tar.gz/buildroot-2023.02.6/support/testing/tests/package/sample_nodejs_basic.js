var assert = require('assert');
assert.strictEqual(1, 1);
console.log("Hello World");
