import django  # noqa: F401
